package com.yadyar.app.ui.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.yadyar.app.ui.dashboard.DashboardScreen
import com.yadyar.app.ui.folders.FolderScreen
import com.yadyar.app.ui.member.MemberFormScreen
import com.yadyar.app.ui.profile.ProfileScreen
import com.yadyar.app.ui.settings.SettingsScreen

object Routes {
    const val DASHBOARD = "dashboard?folderId={folderId}"
    const val PROFILE = "profile/{memberId}"
    const val MEMBER_FORM = "member_form?memberId={memberId}&folderId={folderId}"
    const val SETTINGS = "settings"
    const val FOLDERS = "folders"

    fun profile(memberId: String) = "profile/$memberId"
    fun dashboard(folderId: String?) = if (folderId == null) "dashboard" else "dashboard?folderId=$folderId"
    fun memberForm(memberId: String? = null, folderId: String? = null): String {
        val args = buildList {
            if (memberId != null) add("memberId=$memberId")
            if (folderId != null) add("folderId=$folderId")
        }
        return "member_form" + if (args.isEmpty()) "" else "?" + args.joinToString("&")
    }
}

@Composable
fun AppNavGraph() {
    val navController = rememberNavController()
    NavHost(navController, startDestination = Routes.FOLDERS, modifier = Modifier.fillMaxSize()) {
        composable(Routes.FOLDERS) {
            FolderScreen(
                onOpenMembers = { id -> navController.navigate(Routes.dashboard(id)) },
                onSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }
        composable(Routes.DASHBOARD, arguments = listOf(navArgument("folderId") { type=NavType.StringType; nullable=true; defaultValue=null })) { entry ->
            val folderId = entry.arguments?.getString("folderId")
            DashboardScreen(
                folderId = folderId,
                onMemberClick = { navController.navigate(Routes.profile(it)) },
                onAddMember = { navController.navigate(Routes.memberForm(folderId=folderId)) },
                onEditMember = { navController.navigate(Routes.memberForm(memberId=it, folderId=folderId)) },
                onSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }
        composable(Routes.PROFILE, arguments = listOf(navArgument("memberId") { type=NavType.StringType })) { entry ->
            val id = entry.arguments?.getString("memberId").orEmpty()
            ProfileScreen(memberId=id, onBack={navController.popBackStack()}, onEditMember={navController.navigate(Routes.memberForm(memberId=it))})
        }
        composable(Routes.MEMBER_FORM, arguments = listOf(
            navArgument("memberId") { type=NavType.StringType; nullable=true; defaultValue=null },
            navArgument("folderId") { type=NavType.StringType; nullable=true; defaultValue=null }
        )) { entry ->
            MemberFormScreen(
                memberId=entry.arguments?.getString("memberId"),
                folderId=entry.arguments?.getString("folderId"),
                onBack={navController.popBackStack()}, onSaved={navController.popBackStack()},
                onRemoved={navController.popBackStack(Routes.FOLDERS, inclusive=false)}
            )
        }
        composable(Routes.SETTINGS) { SettingsScreen(onBack={navController.popBackStack()}) }
    }
}
