package com.yadyar.app.ui.settings

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yadyar.app.backup.BackupManager
import com.yadyar.app.security.AppLock
import com.yadyar.app.reminders.ReminderScheduler
import com.yadyar.app.ui.components.ConfirmDialog
import com.yadyar.app.ui.components.GlassCard
import com.yadyar.app.ui.components.GradientBackground
import com.yadyar.app.ui.components.SectionTitle
import com.yadyar.app.ui.theme.DangerRed
import com.yadyar.app.ui.theme.GoldAccent
import com.yadyar.app.ui.theme.SuccessGreen
import com.yadyar.app.ui.theme.TextPrimary
import com.yadyar.app.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showRestoreConfirm by remember { mutableStateOf(false) }
    var pendingRestoreJson by remember { mutableStateOf<String?>(null) }
    var showPinDialog by remember { mutableStateOf(false) }
    var showPatternDialog by remember { mutableStateOf(false) }
    var patternValue by remember { mutableStateOf("") }
    var pinValue by remember { mutableStateOf("") }
    var pinEnabled by remember { mutableStateOf(AppLock.isEnabled(context)) }

    // ---- مجوز نوتیفیکیشن ----
    var notifGranted by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    // ---- خروجی بکاپ ----
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val json = BackupManager.exportToJson(context)
                BackupManager.writeToFile(context, uri, json)
                toast(context, "بکاپ با موفقیت ذخیره شد")
            } catch (e: Exception) {
                toast(context, "خطا در ذخیره بکاپ: ${e.message}")
            }
        }
    }

    // ---- ورودی بکاپ ----
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val text = BackupManager.readFromFile(context, uri)
                pendingRestoreJson = text
                showRestoreConfirm = true
            } catch (e: Exception) {
                toast(context, "خطا در خواندن فایل: ${e.message}")
            }
        }
    }

    val exactOk = ReminderScheduler.canScheduleExact(context)

    GradientBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 18.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 6.dp, bottom = 12.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "بازگشت",
                        tint = TextPrimary
                    )
                }
                Text(
                    text = "تنظیمات",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            // ===== قفل برنامه =====
            SectionTitle("قفل برنامه")
            Spacer(Modifier.height(10.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(if (pinEnabled) "قفل PIN فعال است" else "برای حفاظت از MONO رمز PIN بگذارید", color = TextPrimary, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GlassAction(text = if (pinEnabled) "تغییر رمز" else "تنظیم رمز", icon = Icons.Rounded.CheckCircle, modifier = Modifier.weight(1f), onClick = { pinValue = ""; showPinDialog = true })
                    GlassAction(text = "تنظیم الگو", icon = Icons.Rounded.CheckCircle, modifier = Modifier.weight(1f), onClick = { patternValue=""; showPatternDialog=true })
                    if (pinEnabled) GlassAction(text = "غیرفعال", icon = Icons.Rounded.ErrorOutline, modifier = Modifier.weight(1f), onClick = { AppLock.removePin(context); pinEnabled = false; toast(context, "قفل برنامه غیرفعال شد") })
                }
            }

            // ===== بکاپ =====
            SectionTitle("بکاپ و بازیابی")
            Spacer(Modifier.height(10.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Rounded.Backup,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            "خروجی بکاپ (JSON)",
                            color = TextPrimary,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "همه اعضا، مشخصات و وظایف در یک فایل ذخیره می‌شود",
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    GlassAction(
                        text = "ذخیره خروجی",
                        icon = Icons.Rounded.FileUpload,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
                            exportLauncher.launch("yadyar-backup-$stamp.json")
                        }
                    )
                    GlassAction(
                        text = "بازیابی از فایل",
                        icon = Icons.Rounded.FileDownload,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            importLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                        }
                    )
                }
            }

            // ===== مجوزها =====
            Spacer(Modifier.height(16.dp))
            SectionTitle("مجوزهای یادآوری")
            Spacer(Modifier.height(10.dp))
            GlassCard(modifier = Modifier.fillMaxWidth(), fillSoft = true) {
                PermissionRow(
                    title = "اعلان‌ها (نوتیفیکیشن)",
                    subtitle = "برای نمایش یادآوری‌ها لازم است",
                    ok = notifGranted,
                    actionLabel = "درخواست اجازه",
                    onAction = {
                        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                            putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                        }
                        runCatching { context.startActivity(intent) }
                    }
                )
                Spacer(Modifier.height(8.dp))
                PermissionRow(
                    title = "یادآوری دقیق (Exact Alarm)",
                    subtitle = if (exactOk) {
                        "فعال — یادآورها سرِ ساعت دقیق اجرا می‌شوند"
                    } else {
                        "غیرفعال — برای دقت بالا در تنظیمات اندروید فعالش کنید"
                    },
                    ok = exactOk,
                    actionLabel = "باز کردن تنظیمات",
                    onAction = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                data = Uri.parse("package:${context.packageName}")
                            }
                            runCatching { context.startActivity(intent) }
                        }
                    }
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "اگر مجوزها داده نشوند، فقط نوتیف نمایش داده نمی‌شود؛ " +
                        "ثبت و ویرایش اعضا و وظایف بدون مشکل کار می‌کند.",
                    color = TextSecondary.copy(alpha = 0.75f),
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            // ===== درباره =====
            Spacer(Modifier.height(16.dp))
            SectionTitle("درباره برنامه")
            Spacer(Modifier.height(10.dp))
            GlassCard(modifier = Modifier.fillMaxWidth(), fillSoft = true) {
                AboutRow("نام", "MONO")
                AboutRow("نسخه", "1.0.0")
                AboutRow("ذخیره‌سازی", "کاملاً محلی (SQLite) — بدون اینترنت")
            }

            Spacer(Modifier.height(30.dp))
        }
    }

    if (showRestoreConfirm && pendingRestoreJson != null) {
        ConfirmDialog(
            title = "بازیابی بکاپ",
            text = "تمام داده‌های فعلی جایگزین محتوای فایل بکاپ می‌شوند. این عمل قابل بازگشت نیست. ادامه می‌دهید؟",
            confirmLabel = "بازیابی",
            destructive = true,
            onConfirm = {
                showRestoreConfirm = false
                scope.launch {
                    try {
                        val backup = BackupManager.restoreFromJson(context, pendingRestoreJson!!)
                        toast(
                            context,
                            "بازیابی انجام شد: ${backup.members.size} عضو، ${backup.tasks.size} وظیفه"
                        )
                    } catch (e: Exception) {
                        toast(context, "خطا در بازیابی: ${e.message}")
                    }
                    pendingRestoreJson = null
                }
            },
            onDismiss = {
                showRestoreConfirm = false
                pendingRestoreJson = null
            }
        )
    }
    if (showPatternDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showPatternDialog=false },
            title = { Text("تنظیم الگوی قفل") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("حداقل چهار نقطه را انتخاب کنید: ${patternValue.map { it.digitToInt() }.joinToString(" → ")}")
                    (0..2).forEach { row ->
                        Row {
                            (1..3).forEach { col ->
                                val n=row*3+col
                                androidx.compose.material3.OutlinedButton(onClick={ if(!patternValue.contains(n.toString())) patternValue+=n.toString() }, modifier=Modifier.size(58.dp).padding(3.dp)) { Text(n.toString()) }
                            }
                        }
                    }
                    androidx.compose.material3.TextButton(onClick={patternValue=""}) { Text("پاک‌کردن") }
                }
            },
            confirmButton={ androidx.compose.material3.TextButton(onClick={ if(patternValue.length>=4) { AppLock.setPattern(context, patternValue); pinEnabled=true; showPatternDialog=false; toast(context,"الگوی قفل ذخیره شد") } else toast(context,"الگو باید دست‌کم چهار نقطه داشته باشد") }) { Text("ذخیره") } },
            dismissButton={ androidx.compose.material3.TextButton(onClick={showPatternDialog=false}) { Text("انصراف") } }
        )
    }
    if (showPinDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("تنظیم قفل PIN") },
            text = {
                androidx.compose.material3.OutlinedTextField(
                    value = pinValue,
                    onValueChange = { pinValue = it.filter(Char::isDigit).take(12) },
                    label = { Text("رمز ۴ تا ۱۲ رقمی") },
                    singleLine = true,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword)
                )
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    if (pinValue.length >= 4) { AppLock.setPin(context, pinValue); pinEnabled = true; showPinDialog = false; toast(context, "قفل PIN فعال شد") }
                    else toast(context, "رمز باید دست‌کم ۴ رقم باشد")
                }) { Text("ذخیره") }
            },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { showPinDialog = false }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun GlassAction(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    androidx.compose.material3.TextButton(
        onClick = onClick,
        modifier = modifier
            .height(52.dp)
            .background(
                Color.White.copy(alpha = 0.12f),
                RoundedCornerShape(14.dp)
            )
    ) {
        Icon(icon, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = TextPrimary, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PermissionRow(
    title: String,
    subtitle: String,
    ok: Boolean,
    actionLabel: String,
    onAction: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            if (ok) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline,
            contentDescription = null,
            tint = if (ok) SuccessGreen else DangerRed,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                color = TextPrimary,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                subtitle,
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
        }
        if (!ok) {
            androidx.compose.material3.TextButton(onClick = onAction) {
                Text(actionLabel, color = GoldAccent, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun AboutRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Text(
            label,
            color = TextSecondary,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.width(100.dp)
        )
        Text(
            value,
            color = TextPrimary,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.weight(1f)
        )
    }
}

private fun toast(context: Context, message: String) {
    android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_LONG).show()
}
